<?php
session_start();
$host = "localhost";
$user = "root";
$pass = "";

$db = "todolist";

$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) {
	die("koneksi ke data base gagal: ". mysqli_connect_error());
}
?>
	