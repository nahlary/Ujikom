<?php
include "database.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="stylesLogi.css">
</head>
<body>
<?php
    if(isset($_POST['username'])) {
        $username = $_POST['username'];
        $password = md5($_POST['password']);

        $query = mysqli_query($conn, "SELECT*FROM login where username='$username' and password= '$password'");

        if(mysqli_num_rows($query) > 0){
           $data = mysqli_fetch_array($query);
           $_SESSION['login'] = $data;
           echo '<script>alert("Selamat Datang '.$data['nama'].'"); 
                location.href="index.php";</script>';
                header("location: index.php");
        } else {
           echo '<script>alert("password tidak sesuai.")</script>';
        }
    }
?>
    <div class="login-container">
        <h2>Login</h2>
        
            <div class="form-container" >
                <input type="text" id="taskInput" placeholder="Masukan email">
                <input type="text" id="taskInput" placeholder="Masukan password">
                </div>
            
            <a href="index.php"><button type="submit">Login</button></a>
                <a>Belum punya akun?<a href="register.html">Daftar</a></a></p>
            
        </form>
    </div>
</body>
</html>