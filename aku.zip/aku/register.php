<?php
include "database.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>l
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="stylesRegister.css">
</head>
<body>
<?php
if(isset($_POST['username'])) {
   $nama = $_POST['nama'];
   $username = $_POST['username'];
   $password = md5($_POST['password']);

   $query = mysqli_query($conn, "INSERT INTO tb_user(nama,username,password) values('$nama', '$username', '$password')");
   if($query) {
       echo '<script>alert("Selamat, pendaftaran anda berhasil.");
       location.href="login.php";</script>';
   } else {
       echo '<script>alert("Pendaftaran gagal.")</script>';
   }
}
?>

<form method="post">
    <table align="center">
        <tr>
            <td colspan="2" align="center">
                <h3>Register</h3>
            </td>
        </tr>
        <tr>
            <td>Nama</td>
            <td><input type="text" name="nama"></td>
        </tr>
        <tr>
            <td>Username</td>
            <td><input type="text" name="username"></td>
        </tr>
        <tr>
            <td>Password</td>
            <td><input type="password" name="password"></td>
        </tr>
        <tr>
            <tr>
            <td></td>
            <td>
                <button type="submit">Daftar User</button>
                <a href="login.php">Login</a>
            </td>
            </tr>
        </tr>
    </table>
    </form>
</body>
</html>