<?php

include "database.php";

if (isset($_POST['username'])) {
    $username = $_POST['username'];
    $password = md5($_POST['password']); // Pastikan ini cocok dengan hash di database

    // Ganti "login" dengan "tb_user"
    $query = mysqli_query($conn, "SELECT * FROM tb_user WHERE username='$username' AND password='$password'");

    if (mysqli_num_rows($query) > 0) {
        $data = mysqli_fetch_array($query);
        $_SESSION['tb_user'] = $data;
        $_SESSION["login"] = true;

        echo '<script>
                alert("Selamat Datang ' . $data['nama'] . '"); 
                window.location.href="index.php";
              </script>';
        exit;
    } else {
        echo '<script>alert("Username atau Password tidak sesuai.")</script>';
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="stylesLogin.css">
</head>
<body>

    <div class="login-container">
        <h3>Login User</h3>
        <form method="post">
            <div class="form-group">
                <input type="text" name="username" placeholder="Username" required>
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <div class="login-actions">
                <button type="submit">Login</button>
                <a href="register.php">Daftar</a>
            </div>
        </form>
    </div>

</body>
</html>
