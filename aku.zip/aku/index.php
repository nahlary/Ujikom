
<?php
include 'database.php';

// Proses insert task utama
if(isset($_POST['add'])){
	$task = mysqli_real_escape_string($conn, $_POST['task']);
	$priority = mysqli_real_escape_string($conn, $_POST['priority']);
	$deadline = mysqli_real_escape_string($conn, $_POST['deadline']);

	$q_insert = "INSERT INTO tasks (tasklabel, taskstatus, priority, deadline) VALUES (
	'$task', 'open', '$priority', '$deadline')";
	mysqli_query($conn, $q_insert);
	header('Location: index.php');
	exit();
}

// Proses insert subtask
if(isset($_POST['add_subtask'])){
	$subtask = mysqli_real_escape_string($conn, $_POST['subtask']);
	$parent_task_id = intval($_POST['taskid']);

	$q_insert_sub = "INSERT INTO subtasks (taskid, subtasklabel, status) VALUES (
	'$parent_task_id', '$subtask', 'open')";
	mysqli_query($conn, $q_insert_sub);
	header('Location: index.php');
	exit();
}

// Ubah status subtask
if(isset($_GET['done_sub'])){
	$id = intval($_GET['done_sub']);
	$status = $_GET['status'] == 'open' ? 'close' : 'open';
	$q_update = "UPDATE subtasks SET status = '$status' WHERE id = $id";
	mysqli_query($conn, $q_update);
	header("Location: index.php");
	exit();
}

// Hapus subtask
if(isset($_GET['delete_sub'])){
	$id = intval($_GET['delete_sub']);
	mysqli_query($conn, "DELETE FROM subtasks WHERE id = $id");
	header("Location: index.php");
	exit();
}

// Hapus task utama + subtasks-nya
if(isset($_GET['delete'])){
	$task_id = intval($_GET['delete']);
	mysqli_query($conn, "DELETE FROM subtasks WHERE taskid = $task_id"); // hapus semua subtasks
	mysqli_query($conn, "DELETE FROM tasks WHERE taskid = $task_id"); // hapus task utama
	header("Location: index.php");
	exit();
}

// Ambil data tasks
$q_select = "SELECT * FROM tasks ORDER BY 
			CASE priority 
				WHEN 'high' THEN 1 
				WHEN 'medium' THEN 2 
				WHEN 'low' THEN 3 
			END, deadline ASC";
$run_q_select = mysqli_query($conn, $q_select);
?>

<!DOCTYPE html>
<html lang="id">
<head>
	<meta charset="utf-8">
	<title>To Do List + Subtask</title>
	<link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
	<link rel="stylesheet" href="nahla.css">
	<style>
		.subtasks {
			margin-left: 25px;
			margin-top: 10px;
			padding-left: 15px;
			border-left: 2px solid #ddd;
		}
		.subtasks li {
			list-style: none;
			padding: 5px 10px;
			margin-bottom: 6px;
			border-radius: 8px;
			background: #f9f9f9;
			display: flex;
			align-items: center;
			justify-content: space-between;
			transition: 0.2s ease;
		}
		.subtasks li.done {
			text-decoration: line-through;
			color: gray;
			background-color: #e8e8e8;
		}
		.subtasks li:hover {
			background-color: #e2f0ff;
		}
		.subtask-form {
			display: flex;
			gap: 8px;
			margin-top: 8px;
			margin-left: 25px;
		}
		.subtask-form input[type="text"] {
			flex: 1;
			padding: 5px;
			border-radius: 6px;
			border: 1px solid #ccc;
		}
		.subtask-form button {
			padding: 5px 10px;
			background-color: #4CAF50;
			color: white;
			border: none;
			border-radius: 6px;
			cursor: pointer;
		}
		.subtask-form button:hover {
			background-color: #45a049;
		}
	</style>
</head>
<body>
<div class="container">
	<div class="header">
		<div class="title"><i class='bx bx-sun'></i><span>To Do List</span></div>
		<div class="description"><?= date("l, d M Y") ?></div>
		<a href="logout.php" class="logout-button">Logout</a>
	</div>
	<div class="content">

		<!-- Form tambah task -->
		<div class="card">
			<form action="" method="post">
				<input type="text" name="task" class="input-control" placeholder="Tambahkan tugas" required>
				<select name="priority" required>
					<option value="high">High</option>
					<option value="medium">Medium</option>
					<option value="low">Low</option>
				</select>
				<input type="date" name="deadline" class="input-control" required>
				<div class="text-right"><button type="submit" name="add">Add</button></div>
			</form>
		</div>

		<?php if(mysqli_num_rows($run_q_select) > 0): ?>
			<?php while($r = mysqli_fetch_array($run_q_select)): ?>
				<div class="card">
					<!-- Tugas utama -->
					<div class="task-item <?= $r['taskstatus'] == 'close' ? 'done' : '' ?>">
						<div>
							<input type="checkbox" onclick="window.location.href='?done=<?= $r['taskid'] ?>&status=<?= $r['taskstatus'] ?>'" <?= $r['taskstatus'] == 'close' ? 'checked' : '' ?>>
							<span><?= htmlspecialchars($r['tasklabel']) ?> - <b><?= ucfirst($r['priority']) ?></b></span>
							<small>(<?= !empty($r['deadline']) ? date("d M Y", strtotime($r['deadline'])) : 'Tanpa Deadline' ?>)</small>
						</div>
						<div>
							<a href="edit.php?id=<?= $r['taskid'] ?>" class="text-orange"><i class="bx bx-edit"></i></a>
							<a href="?delete=<?= $r['taskid'] ?>" class="text-red" onclick="return confirm('Yakin ingin menghapus?')"><i class="bx bx-trash"></i></a>
						</div>
					</div>

					<!-- Subtasks -->
					<?php
						$taskid = $r['taskid'];
						$subtask_query = mysqli_query($conn, "SELECT * FROM subtasks WHERE taskid = $taskid");
					?>
					<?php if(mysqli_num_rows($subtask_query) > 0): ?>
						<ul class="subtasks">
							<?php while($sub = mysqli_fetch_array($subtask_query)): ?>
								<li class="<?= $sub['status'] == 'close' ? 'done' : '' ?>">
									<span>
										<input type="checkbox" onclick="window.location.href='?done_sub=<?= $sub['id'] ?>&status=<?= $sub['status'] ?>'" <?= $sub['status'] == 'close' ? 'checked' : '' ?>>
										<?= htmlspecialchars($sub['subtasklabel']) ?>
									</span>
									<a href="?delete_sub=<?= $sub['id'] ?>" class="text-red" title="Hapus Subtask" onclick="return confirm('Hapus subtask ini?')"><i class="bx bx-trash"></i></a>
								</li>
							<?php endwhile; ?>
						</ul>
					<?php endif; ?>

					<!-- Form tambah subtask -->
					<form action="" method="post" class="subtask-form">
						<input type="hidden" name="taskid" value="<?= $r['taskid'] ?>">
						<input type="text" name="subtask" placeholder="Tambah subtask..." required>
						<button type="submit" name="add_subtask">+</button>
					</form>
				</div>
			<?php endwhile; ?>
		<?php else: ?>
			<div>Belum ada tugas</div>
		<?php endif; ?>
	</div>
</div>
</body>
</html>
